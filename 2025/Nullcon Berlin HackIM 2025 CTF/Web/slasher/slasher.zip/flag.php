<?php

    $FLAG = "ENO{LOCAL_TESTING_ONLY}"; // not the real flag, just for local testing

?>